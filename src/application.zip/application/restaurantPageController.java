package application;

public class restaurantPageController {

}
