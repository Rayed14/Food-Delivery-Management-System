package application;

public class adminPageController {

}
