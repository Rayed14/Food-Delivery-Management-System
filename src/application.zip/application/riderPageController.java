package application;

public class riderPageController {

}
